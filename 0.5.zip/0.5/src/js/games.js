async function getjson(url) {
  const response = await fetch(url)
  const Json = await response.json()
  return Json
}
let swflist = []
let apklist = []
let jarlist = []
let gameslist = getjson("./src/js/data.json")
gameslist.then(Json =>gameslist = Json
).then(function(gameslist) {
    swflist = gameslist.swf.sort(function(a, b) {
      return a.nome < b.nome ? -1: a.nome > b.nome ? 1: 0;
    })
    apklist = gameslist.apk.sort(function(a, b) {
      return a.nome < b.nome ? -1: a.nome > b.nome ? 1: 0;
    })
    jarlist = gameslist.jar.sort(function(a, b) {
      return a.nome < b.nome ? -1: a.nome > b.nome ? 1: 0;
    })
    swflist.forEach(function gamecard(game) {
      const games = document.querySelector('#swf-games')
      games.innerHTML += `
      <div class="game-card">
      <img src="${game.img}" alt="${game.nome}" />

      <div class="card-bottom">
      <p>
      ${game.nome}
      </p>
      <a href="${game.link}">Download</a>
      </div>
      </div>
      `
    })
    jarlist.forEach(function gamecard(game) {
      const games = document.querySelector('#jar-games')
      games.innerHTML += `
      <div class="game-card">
      <img src="${game.img}" alt="${game.nome}" />

      <div class="card-bottom">
      <p>
      ${game.nome}
      </p>
      <a href="${game.link}">Download</a>
      </div>
      </div>
      `
    })
    apklist.forEach(function gamecard(game) {
      const games = document.querySelector('#apk-games')
      games.innerHTML += `
      <div class="game-card">
      <img src="${game.img}" alt="${game.nome}" />

      <div class="card-bottom">
      <p>
      ${game.nome}
      </p>
      <a href="${game.link}">Download</a>
      </div>
      </div>
      `
    })
  })